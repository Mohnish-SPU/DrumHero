Install the songlib

http://beastie.cs.ua.edu/songlib/
