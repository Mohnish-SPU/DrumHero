Install the songlib
from
http://beastie.cs.ua.edu/songlib/


 download the samples folder on 
 https://github.com/Mohnish-SPU/DrumHero.git
and replace it with the samples folder

P.S.
Including only my generated .rra files it still exceeds 2 MB
